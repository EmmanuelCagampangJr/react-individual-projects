import React from 'react';
import ReactDOM from 'react-dom/client';
import './styles/global.css'; // global styles for resets and variables
import App from './App';       // your main app component

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
