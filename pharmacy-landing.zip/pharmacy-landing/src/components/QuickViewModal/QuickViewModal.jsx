import React from 'react';
import './QuickViewModal.css';

export default function QuickViewModal({ product, onClose }) {
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content" onClick={e=>e.stopPropagation()}>
        <h3>{product.name} — Quick View</h3>
        <p>{product.desc}</p>
        <p>Price: ${product.price.toFixed(2)}</p>
        <button onClick={onClose}>Close</button>
      </div>
    </div>
  );
}
