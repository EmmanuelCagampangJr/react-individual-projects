import React, { useState } from 'react';
import PRODUCTS from '../../data/products';
import ProductCard from '../ProductCard/ProductCard';

export default function ProductListContainer() {
  const [selections, setSelections] = useState({});

  const handleQuantityChange = (id, qty) => {
    console.log('qty changed:', id, qty);
    setSelections(sel => ({
      ...sel,
      [id]: { ...sel[id], qty }
    }));
  };

  const handleSizeChange = (id, size) => {
    console.log('size changed:', id, size);
    setSelections(sel => ({
      ...sel,
      [id]: { ...sel[id], size }
    }));
  };

  const handleColorChange = (id, color) => {
    console.log('color changed:', id, color);
    setSelections(sel => ({
      ...sel,
      [id]: { ...sel[id], color }
    }));
  };

  const handleQuickView = id => {
    console.log('quick view requested for', id);
    // TODO: set state for showing modal if needed
  };

  return (
    <section className="products">
      {PRODUCTS.map(product => (
        <ProductCard
          key={product.id}
          product={product}
          onQuantityChange={handleQuantityChange}
          onSizeChange={handleSizeChange}
          onColorChange={handleColorChange}
          onQuickView={handleQuickView}
        />
      ))}
    </section>
  );
}

console.log("Rendering ProductListContainer, PRODUCTS:", PRODUCTS);
