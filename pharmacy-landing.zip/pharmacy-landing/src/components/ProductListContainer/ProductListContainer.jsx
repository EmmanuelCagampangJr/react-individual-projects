import React, { useState } from 'react';
import PRODUCTS from '../../data/products';
import ProductCard from '../ProductCard/ProductCard';
import './ProductListContainer.css'; // Ensure this import is present

export default function ProductListContainer() {
  const [selections, setSelections] = useState({});

  const handleQuantityChange = (id, qty) => {
    setSelections(sel => ({
      ...sel,
      [id]: { ...sel[id], qty }
    }));
  };

  const handleSizeChange = (id, size) => {
    setSelections(sel => ({
      ...sel,
      [id]: { ...sel[id], size }
    }));
  };

  const handleColorChange = (id, color) => {
    setSelections(sel => ({
      ...sel,
      [id]: { ...sel[id], color }
    }));
  };

  const handleQuickView = id => {
    // TODO: set state for showing modal if needed
  };

  return (
    <> {/* Use a fragment */}
      <section className="products">
        {PRODUCTS.map(product => (
          <ProductCard
            key={product.id}
            product={product}
            onQuantityChange={handleQuantityChange}
            onSizeChange={handleSizeChange}
            onColorChange={handleColorChange}
            onQuickView={handleQuickView}
          />
        ))}
      </section>

      {/* ADD THIS TEMPORARY DEBUGGING DIV to use 'selections' and clear warning */}
      <div style={{ margin: '2rem', padding: '1rem', border: '1px solid var(--border-color)', borderRadius: '4px', backgroundColor: 'var(--secondary-color)', color: 'var(--text-color)', textAlign: 'left', overflowX: 'auto' }}>
        <h3>Current Selections (for debugging):</h3>
        <pre>{JSON.stringify(selections, null, 2)}</pre>
      </div>
    </>
  );
}