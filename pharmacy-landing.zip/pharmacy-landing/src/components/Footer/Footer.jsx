import React from 'react';
import './Footer.css';

export default function Footer() {
  return (
    <footer className="footer">
      <a href="#">About Us</a> | 
      <a href="#">Contact</a> | 
      <a href="#">Privacy Policy</a>
    </footer>
  );
}
