export default function Navbar({ brand, active, onToggleProducts }) {
  return (
    <nav className="navbar">
      <span className="navbar-brand">{brand}</span>
      <button
        className={`navbar-toggle ${active ? 'active' : ''}`}
        onClick={onToggleProducts}
      >
        Products
      </button>
    </nav>
  );
}
