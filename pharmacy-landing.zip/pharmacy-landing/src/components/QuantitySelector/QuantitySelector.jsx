export default function QuantitySelector({ options, onChange }) {
  return (
    <select
      className="qty-select"
      onChange={e => onChange(Number(e.target.value))}
    >
      {options.map(q => (
        <option key={q} value={q}>{q}</option>
      ))}
    </select>
  );
}
