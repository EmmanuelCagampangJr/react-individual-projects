export default function SizeColorSelector({ sizes, colors, onSizeChange, onColorChange }) {
  return (
    <div className="size-color">
      <select onChange={e => onSizeChange(e.target.value)}>
        {sizes.map(s => <option key={s} value={s}>{s}</option>)}
      </select>
      <select onChange={e => onColorChange(e.target.value)}>
        {colors.map(c => <option key={c} value={c}>{c}</option>)}
      </select>
    </div>
  );
}
