import React from 'react';
import QuantitySelector from "../QuantitySelector/QuantitySelector";
import SizeColorSelector from "../SizeColorSelector/SizeColorSelector";

export default function ProductCard({
  product,
  onQuantityChange,
  onSizeChange,
  onColorChange,
  onQuickView
}) {
  return (
    <div className="product-card">
      {/* ADDED: Product Name, Price, and Description */}
      <h3 className="name">{product.name}</h3>
      <p className="price">${product.price.toFixed(2)}</p>
      <p className="description">{product.description}</p>

      <QuantitySelector
        options={product.options.quantities}
        onChange={val => onQuantityChange(product.id, val)}
      />

      <SizeColorSelector
        sizes={product.options.sizes}
        colors={product.options.colors}
        onSizeChange={val => onSizeChange(product.id, val)}
        onColorChange={val => onColorChange(product.id, val)}
      />
      

      <button
        disabled={product.prescription}
        className="add-to-cart"
      >
        {product.prescription ? 'Requires Prescription' : 'Add to Cart'}
      </button>

      <button
        className="quick-view"
        onClick={() => onQuickView(product.id)}
        aria-label={`Quick view ${product.name}`}
      >
        Quick View
      </button>
    </div>
  );
}