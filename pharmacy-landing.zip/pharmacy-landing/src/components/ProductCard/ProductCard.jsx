import QuantitySelector from './QuantitySelector'; // Ensure this is present and path is correct
import SizeColorSelector from "../SizeColorSelector/SizeColorSelector";
export default function ProductCard({
  product,
  onQuantityChange,
  onSizeChange,
  onColorChange,
  onQuickView
}) {
  // we no longer need local state here—just call back
  return (
    <div className="product-card">
      <h3 className="name">{product.name}</h3> {/* Add this line */}
      <p className="price">${product.price.toFixed(2)}</p> {/* Add this line */}
      <p className="description">{product.description}</p> {/* Add this line */}
      <QuantitySelector
        options={product.options.qty}
        onChange={val => onQuantityChange(product.id, val)}
      />

      <SizeColorSelector
        sizes={product.options.size}
        colors={product.options.color}
        onSizeChange={val => onSizeChange(product.id, val)}
        onColorChange={val => onColorChange(product.id, val)}
      />

      <button
        disabled={product.prescription}
        className="add-to-cart"
      >
        {product.prescription ? 'Requires Prescription' : 'Add to Cart'}
      </button>

      <button
        className="quick-view"
        onClick={() => onQuickView(product.id)}
        aria-label={`Quick view ${product.name}`}
      >
        Quick View
      </button>
    </div>
  );
}
