import React, { useState } from 'react';
import Navbar from './components/Navbar/Navbar';
import ProductListContainer from './components/ProductListContainer/ProductListContainer';
import Footer from './components/Footer/Footer';

function App() {
  const [showProducts, setShowProducts] = useState(false);

  return (
    <>
      <Navbar
        brand="EmmanuelPharmacy"
        active={showProducts}
        onToggleProducts={() => setShowProducts(prev => !prev)}
      />
      {showProducts && <ProductListContainer />}
      <Footer />
    </>
  );
}

export default App;
